# website notepad

A Pen created on CodePen.

Original URL: [https://codepen.io/yxsnhifq-the-flexboxer/pen/QwyGmbM](https://codepen.io/yxsnhifq-the-flexboxer/pen/QwyGmbM).

